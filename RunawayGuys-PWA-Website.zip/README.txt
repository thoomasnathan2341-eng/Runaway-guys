RUNAWAY GUYS PWA WEBSITE FILES

These files must be published to a public HTTPS website before PWABuilder can package them.
Upload the CONTENTS of this folder to a GitHub repository, then enable GitHub Pages:
Repository > Settings > Pages > Deploy from a branch > main > /(root) > Save.
Wait for GitHub Pages to provide the public URL. Enter that URL in PWABuilder.

This ZIP is the website source, not an APK.
