RUNAWAY GUYS — Android project
This is a playable rooftop parkour prototype packaged in a native Android WebView app.

To build an APK:
1. Install Android Studio on a computer.
2. Open this extracted RunawayGuys folder in Android Studio.
3. Let Gradle sync finish (requires internet the first time).
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Find the APK at app/build/outputs/apk/debug/app-debug.apk.

This chat environment cannot compile/sign an Android APK, so this ZIP contains the complete Android Studio project rather than a ready-to-install APK.
